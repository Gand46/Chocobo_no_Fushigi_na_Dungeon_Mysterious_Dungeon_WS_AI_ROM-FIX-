"""Self-contained Spanish QA27 native regression report and evidence bundle."""
from pathlib import Path
import base64,datetime,hashlib,html,json,zipfile
ROOT=Path(__file__).resolve().parent
result=json.loads((ROOT/'QA27_HF20_Guardado_Regresion_Resultados.json').read_text())
def img(name):return 'data:image/png;base64,'+base64.b64encode((ROOT/name).read_bytes()).decode()
styles='''body{font:17px/1.52 system-ui,sans-serif;max-width:1040px;margin:auto;padding:32px;background:#f1f3ee;color:#27352a}h1,h2{line-height:1.2}section{background:white;border-radius:12px;padding:22px;margin:18px 0}table{border-collapse:collapse;width:100%}th,td{padding:9px;border-bottom:1px solid #ccc;text-align:left}.pair{display:grid;grid-template-columns:1fr 1fr;gap:12px}figure{margin:0}figure img{width:100%;image-rendering:pixelated}figcaption{font-weight:600}code{font-size:13px;overflow-wrap:anywhere}@media(max-width:650px){body{padding:14px}.pair{grid-template-columns:1fr}}'''
parts=[f'<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Chocobo HF20 · Guardado y regresión QA27</title><style>{styles}</style>',
'<p>CHOCOBO WONDER SWAN · HF20 TEST · QA27 · 15 OCTUBRE 2026</p><h1>El guardado y los casos funcionales ensayados conservan su comportamiento</h1>',
'<p>HF20 se comparó con HF19 usando la misma entrada de cada caso. Se ejecutaron ocho sesiones nuevas en Mesen, cuatro por versión, con escrituras nativas del juego y procesos independientes para cargar en frío. Resultado: <strong>89 controles aprobados</strong>.</p>',
'<section><h2>Hallazgos</h2><table><thead><tr><th>Área</th><th>Resultado</th></tr></thead><tbody>',
'<tr><td>Guardar</td><td>2.516 bytes escritos por la rutina nativa; SRAM de 32 KiB idéntica entre HF19 y HF20. CRC, complemento y marca de confirmación válidos.</td></tr>',
'<tr><td>Apagar y cargar</td><td>Procesos nuevos de emulación: dos copias nativas exactas de 2.516 bytes; datos persistentes conservados. Retorno al piso 31, área 3, evento 0000.</td></tr>',
'<tr><td>Equipo e inventario</td><td>Seis casos: menú de vuelta al campo en ambas ROM, sin eventos en los guardias de búfer ni escrituras persistentes inesperadas.</td></tr>',
'<tr><td>Combate asistido</td><td>Mismo resultado y estado final, con HP enemigo a cero; 13 capturas idénticas.</td></tr>',
'<tr><td>Alcance binario</td><td>352 bytes cambiados, dentro de los 14 bloques de diálogo aprobados y checksum. Código y fuente idénticos. BPS acumulativo aplicado a la ROM japonesa y verificado.</td></tr>',
'</tbody></table><p>En total coinciden byte por byte <strong>56 capturas</strong> entre HF19 y HF20 (19 guardado, seis carga, 18 equipo y 13 combate).</p></section>',
'<section><h2>Procedencia y límites</h2><p>Las pruebas de guardado seleccionan de forma sintética la pantalla de escalera y después usan la confirmación y copia nativas. El equipo se prepara sintéticamente; el jefe recibe ayuda explícita. Las imágenes y estados iniciales fueron los mismos para ambas ROM. Estas ejecuciones confirman las rutas ensayadas, sin demostrar un recorrido natural completo, otro emulador ni hardware.</p>',
f'<p>HF19 SHA-256:<br><code>{result["base_rom_sha256"]}</code><br>HF20 SHA-256:<br><code>{result["tested_rom_sha256"]}</code><br>Archivo de guardado generado:<br><code>{result["protected_save_sha256"]}</code></p></section>',
'<h2>Capturas nativas comparadas</h2><p>Los cuatro pares siguientes son una muestra del total. El paquete de evidencia conserva las 56 capturas de cada versión, registros, archivos SRAM y el verificador.</p>']
for title,phase,pic in [('Guardado: retorno al piso 31','save','f01800.png'),('Carga en frío: escena reanudada','cold','f04300.png'),('Inventario: equipo comprobado','equipment','slot17_9D_flags10_f1860.png'),('Combate asistido: estado final','boss','f04800.png')]:
    parts.append(f'<section><h2>{title}</h2><div class="pair">')
    for v in ('HF19','HF20'):parts.append(f'<figure><figcaption>{v}</figcaption><img alt="{html.escape(title)} en {v}" src="{img(phase+"_"+v+"/"+pic)}"></figure>')
    parts.append('</div></section>')
parts.append('<section><h2>Reproducción</h2><p><code>verify_regression.py</code> comprueba hashes, límites binarios, escrituras y capturas desde los registros incluidos y las ROM reconstruidas con las fuentes HF20. El archivo JSON enumera los 89 controles. No se modificó la ROM en esta fase.</p></section></html>')
report=ROOT/'QA27_HF20_Guardado_y_Regresion.html';report.write_text('\n'.join(parts),encoding='utf-8')
assert report.read_text().count('<img ')==8
source=ROOT.parent/'hf18_recovered'
script_names=['qa13/driver.lua','qa13/run.py','qa13/save_caller_trace.lua','qa13/save_native_trace.lua','qa13/stair_save.lua','qa13/cold_event_trace.lua','qa6/load_data_trace.lua','qa3/cold_verified.lua','qa13/equipment_sorted/run_suite.py','qa13/equipment_sorted/native_suite.lua','qa13/equipment_sorted/cases_equip.lua','qa13/d2_boss_assist.lua','qa13/event_progress.lua','qa7/chocobo_save.py']
package=ROOT.parent/'Chocobo_HF20_QA27_Guardado_Regresion_Evidencias_20261015.zip'
with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7)as z:
    for p in sorted(ROOT.glob('*')):
        if p.is_file()and p.suffix not in ('.ws',):z.write(p,p.name)
        elif p.is_dir() and p.name.endswith(('HF19','HF20')):
            for f in sorted(p.rglob('*')):
                if f.is_file():z.write(f,'runs/'+f.relative_to(ROOT).as_posix())
    for n in script_names:z.write(source/n,'replay_scripts/'+n)
print(json.dumps({'report':str(report),'bundle':str(package),'bundle_sha256':hashlib.sha256(package.read_bytes()).hexdigest(),'bytes':package.stat().st_size},indent=2))
