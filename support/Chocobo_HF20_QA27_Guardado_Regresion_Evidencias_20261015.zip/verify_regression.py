"""HF19/HF20 independent native save and gameplay comparison, no source edits."""
from pathlib import Path
import csv,hashlib,json,sys,datetime,zoneinfo
R=Path(__file__).resolve().parent
PROJECT=R.parent/'hf18_recovered'
sys.path.insert(0,str(PROJECT/'qa7'))
from chocobo_save import inspect
sys.path.insert(0,str(PROJECT))
from tools.reference_bps.bps import apply
sha=lambda b:hashlib.sha256(b).hexdigest()
def data(path):return (R/path).read_bytes()
def u16(b,i):return int.from_bytes(b[i:i+2],'little')
checks=[]
def ck(label,ok,details=None):
    if not ok:raise AssertionError(label)
    checks.append({'name':label,'status':'PASS','details':details})
roms={v:data(f'Chocobo_QA27_{v}_TEST.ws')for v in ('HF19','HF20')}
manifest=json.loads((PROJECT/'manifest.json').read_text());base=roms['HF19'];candidate=roms['HF20']
ck('HF20 pinned ROM',sha(candidate)==manifest['target']['sha256'],sha(candidate))
ck('HF19 pinned baseline',sha(base)==manifest['previous_hf19']['sha256'],sha(base))
rawjp=(R.parent/'jp_recovery/Chocobo_JP.ws').read_bytes()
ck('Cumulative BPS independently applied to Japanese base',apply(rawjp,(PROJECT/'patches/Chocobo_EN_v1.1_HF20_TEST_JP_CCAA4853.bps').read_bytes())==candidate)
edits=json.loads((PROJECT/'qa26/edits.json').read_text());allowed={len(candidate)-2,len(candidate)-1}
for e in edits:
    offset=int(e['offset'],16);before=bytes.fromhex(e['before']);after=bytes.fromhex(e['after'])
    ck('Preimage and output '+e['id'],base[offset:offset+len(before)]==before and candidate[offset:offset+len(after)]==after)
    allowed.update(range(offset,offset+len(before)))
diff={i for i,(a,b)in enumerate(zip(base,candidate))if a!=b}
ck('Exactly 352 changed bytes inside fourteen text extents and checksum',len(diff)==352 and diff<=allowed)
ck('Code and font banks unchanged',base[0x140000:0x190000]==candidate[0x140000:0x190000])
runhash={v:sha(roms[v])for v in roms}
for phase in ('save','cold','equipment','boss'):
    for v in roms:
        p=R/f'{phase}_{v}';m=json.loads((p/'run.json').read_text())
        ck(f'{phase} {v} completed native with exact ROM',m['exit']==0 and m['completed'] and m['rom_sha256']==runhash[v] and not m.get('timed_out',False))
        expected_state={'save':'9d5761437d73152c11f1fe2b5972972a6ce4d9fb74ef119b0f7b0e9da3129b8a',
                        'cold':None,'equipment':'2cb9e29b3749ce0caf9628ff93f8c5b52ebe5eb7212627175290a38d9adb5f82',
                        'boss':'05eb69ec2ecdd6c097b30628bd4e22f231a3b0629c319f6da948cd5577b38ec4'}[phase]
        ck(f'{phase} {v} source state',m.get('state_sha256')==expected_state)
        if phase in ('save','cold','boss'):
            ck(f'{phase} {v} native plan hash',sha((p/'plan.lua').read_bytes())==m['plan_sha256'])
        else:
            ck(f'{phase} {v} native script and cases',sha((p/'observer.lua').read_bytes())==m['script_sha256'] and sha((p/'cases.lua').read_bytes())==m['cases_sha256'])

def same(phase,files):
    for f in files:
        ck(phase+' identical HF19/HF20 '+f,data(f'{phase}_HF19/{f}')==data(f'{phase}_HF20/{f}'))
same('save',['before_copy.sav','after_copy.sav','native_save_after.sav','sram.bin','payload_write_count.txt','writes.csv','frames.csv'])
saved=data('save_HF20/native_save_after.sav');before=data('save_HF20/before_copy.sav');after=data('save_HF20/after_copy.sav')
ck('2516 native payload byte writes',int((R/'save_HF20/payload_write_count.txt').read_text())==2516)
ck('Live save copied exactly into protected slot',before[0x6bd8:0x75ac]==after[0x75b6:0x7f8a]==saved[0x75b6:0x7f8a])
ck('Native protected CRC/complement/commit',inspect(saved)['protected_valid'],{k:v for k,v in inspect(saved).items() if k in ('crc_stored','crc_calculated','committed_mask','protected_mask','commit')})
ck('32 KiB raw save identical across versions',len(saved)==32768 and saved==data('save_HF19/native_save_after.sav'),sha(saved))
same('cold',['input_save.sav','sram.bin','frames.csv','load_count.txt','transition_writes.csv','load_1_copied.sav','load_2_copied.sav'])
inp=data('cold_HF20/input_save.sav');final=data('cold_HF20/sram.bin')
ck('New process cold loads exactly the newly written save',inp==saved)
ck('Two native load copies, full 2516 bytes each',int((R/'cold_HF20/load_count.txt').read_text())==2 and all(data(f'cold_HF20/load_{i}_copied.sav')[0x6bd8:0x75ac]==inp[0x75b6:0x7f8a]for i in (1,2)))
stored=lambda b:b[0x75ac:0x75b4]+b[0x75b6:0x7f90]
ck('Protected save remains valid and identical after cold restart',stored(final)==stored(inp) and inspect(final)['protected_valid'])
ck('Cold resumed floor 31, area 3, event 0000',u16(final,0x7303)==31 and final[0x7301]==3 and u16(final,0x7335)==0)
same('equipment',['results.csv','events.csv','properties.csv','text_reads.csv','buffer_guard.csv','persistent_writes.csv','completed.txt'])
with (R/'equipment_HF20/results.csv').open()as f:rows=list(csv.DictReader(f))
ck('Six equipment checks return to field',len(rows)==6 and all(r['menu_state']=='0011'and r['poweroff']=='false'for r in rows))
for name in ('buffer_guard.csv','persistent_writes.csv'):
    ck('No equipment '+name+' events',not list(csv.DictReader((R/'equipment_HF20'/name).open())))
same('boss',['sram.bin','wram.bin','frames.csv','script_states.csv','completed.txt'])
boss=data('boss_HF20/sram.bin')
ck('Assisted boss reaches death state, consistent with HF19',u16(boss,0x5a34)==0)
image_counts={}
for phase in ('save','cold','equipment','boss'):
    old={p.name:p for p in (R/f'{phase}_HF19').glob('*.png')}
    new={p.name:p for p in (R/f'{phase}_HF20').glob('*.png')}
    ck(phase+' same captured frame set',old.keys()==new.keys())
    ck(phase+' all screenshots pixel bytes identical',all(old[n].read_bytes()==p.read_bytes()for n,p in new.items()),len(new))
    image_counts[phase]=len(new)

result={'status':'PASS_SCOPED_NATIVE_HF19_HF20_SAVE_AND_GAMEPLAY_REGRESSION','date_bogota':datetime.datetime.now(zoneinfo.ZoneInfo('America/Bogota')).isoformat(),
        'base_rom_sha256':sha(base),'tested_rom_sha256':sha(candidate),'scope':'synthetic native save/cold load, six equipped inventory cases, assisted boss; no natural playthrough or hardware',
        'sessions':8,'native_payload_bytes_per_copy':2516,'protected_save_sha256':sha(saved),'screenshots_identical':image_counts,
        'changed_resources':14,'changed_bytes':len(diff),'checks_passed':len(checks),'checks':checks,
        'limits':['No natural unassisted complete playthrough or hardware test','General functionality outside these bounded scenarios is inherited from unchanged code and earlier tests, not newly observed in every route','Emulator savestate source stems from HF9 but control and tested HF19/HF20 receive the exact same source state']}
(R/'QA27_HF20_Guardado_Regresion_Resultados.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ('checks','limits')},ensure_ascii=False,indent=2))
